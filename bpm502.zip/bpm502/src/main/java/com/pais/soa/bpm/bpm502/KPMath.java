package com.pais.soa.bpm.bpm502;

import java.math.BigDecimal;
import java.net.URI;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.pais.soa.bpm.common.SoaResponseHeader;
import com.pais.soa.bpm.model.RecordOut_Daily_Sales;
import com.pais.soa.bpm.model.ResponseStatus;
import com.pais.soa.bpm.model.odsRelatedModels.ODSResponse;
import com.pais.soa.bpm.utils.RestUtils;
import lombok.extern.slf4j.Slf4j;

@Component
@WebService
public class KPMath {
	
	@Value("${soa.bpm.be_url}")
	String be_url;

    private ExecutorService executor = Executors.newFixedThreadPool(1);
    
    @Value("#{${soa.bpm501.token_user_persysid}}")
	Map<String, Integer> token_user_persysid;


@XmlAccessorType( XmlAccessType.FIELD )
public static class WellFormedAnswer{

	BPM502FEResponse bpm501feResponse;
}
	@WebMethod
	public WellFormedAnswer add(BPM502FERequest bpm501feRequest) throws InterruptedException, ExecutionException, TimeoutException {
		WellFormedAnswer ans=new WellFormedAnswer();
			
		RestTemplate restTemplate = new RestTemplate();

//        log.info("501 BE request: \n{}\n", bpm501feRequest);

        	var syscred=token_user_persysid.get(bpm501feRequest.getSOA_Header().getSysID());	
      		if(null==syscred) {
      			
//      			log.info("the specified sys id "+bpm501feRequest.getSOA_Header().getSysID()+" does not allowed" );
      			throw new IllegalArgumentException("the specified sys id "+bpm501feRequest.getSOA_Header().getSysID()+" does not allowed" );
      		}
             
        	Object[] params = new Object[3];
            Integer pos_market_type_code = syscred;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
      		LocalDate fromDate = LocalDate.parse(bpm501feRequest.getSOA_Body().getFromDate(), formatter);
            Integer rangeDaysBack = bpm501feRequest.getSOA_Body().getRangeDaysBack();
            params[0]=pos_market_type_code;
            params[1]=java.sql.Date.valueOf(fromDate.minusDays(rangeDaysBack));
            params[2]=java.sql.Date.valueOf(fromDate);
          	
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(be_url).queryParam("params",params);
            URI uri = builder.build().encode().toUri();

            //execute the request
            Future<ResponseEntity<ODSResponse>> future =
                    executor.submit(() ->
                            restTemplate.exchange(uri, HttpMethod.GET, null, ODSResponse.class));

            ResponseEntity<ODSResponse> response = future.get(1000l, TimeUnit.MILLISECONDS);
//            response.getHeaders().toString();

            BPM502FEResponse bpm501feResponse = new BPM502FEResponse();

            SoaResponseHeader SOA_Header = new SoaResponseHeader();
            SOA_Header.setSysID("" + bpm501feRequest.getSOA_Header().getSysID());

            SOA_Header.setUUID(bpm501feRequest.getSOA_Header().getUUID());

            //in case the operation done improperly.
            if (response.getStatusCode().value() != 200) {
            	
            	   SOA_Header.setResultCode(ResponseStatus.DAL_SERVER_SIDE_ERROR);

                   SOA_Header.setResultMessage("Cant Finish The Operation Properly");
            
                   bpm501feResponse.setBody(null);

            }
            else {
            	 SOA_Header.setResultCode(ResponseStatus.OK);

                 SOA_Header.setResultMessage("Operation Done Properly");
                 
                 List<RecordOut_Daily_Sales> recordOut_Daily_Sales = getSummary(response.getBody());
              
                 bpm501feResponse.setBody(recordOut_Daily_Sales);
            
            }
            
           bpm501feResponse.setSOA_Header(SOA_Header);
		
		   ans.bpm501feResponse=bpm501feResponse;
   		
		   return ans;
		   
	}
	

    private List<RecordOut_Daily_Sales> getSummary(ODSResponse odsResponse) {

        try {
        	
              List<HashMap> body = odsResponse.getBody();
              
              List<RecordOut_Daily_Sales> records = new ArrayList<>();

              for (HashMap query : body) {     	  
              	  
            	//convert String LocalDateTime to LocalDate
               String source_sales_dt1=(String)query.get("DATE");
//               log.info("source_sales_dt1 \n{}\n",source_sales_dt1);
                  
          	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
          	    LocalDate sales_dt = LocalDate.parse(source_sales_dt1, formatter);
//                log.info("localDate \n{}\n",sales_dt);

              	Number dist_no=(Number) query.get("DIST_NO");
              	
              	String dist_name=(String) query.get("DIST_NAME");
              	
              	Number pos_no=(Number) query.get("POS_NO");
              	
              	String pos_name=(String) query.get("POS_NAME");
              	
              	Number pos_market_type_code=(Number) query.get("POS_MARKET_TYPE_CODE");
              	
              	String pos_market_type_desc=(String) query.get("POS_MARKET_TYPE_DESC");      	
              	
              	Number pos_status_code=(Number) query.get("POS_STATUS_CODE");
              	
              	String pos_status_desc=(String) query.get("POS_STATUS_DESC");
              	
              	Number lct_category_code=(Number) query.get("LCT_CATEGORY_CODE");
              	
              	String lct_category_desc=(String) query.get("LCT_CATEGORY_DESC");
              	
              	Number lct_type_code=(Number) query.get("LCT_TYPE_CODE");
              	
              	String lct_type_desc=(String) query.get("LCT_TYPE_DESC");
              	
              	Number physical_loc_code=(Number) query.get("PHYSICAL_LOC_CODE");
              	
              	String physical_loc_desc=(String) query.get("PHYSICAL_LOC_DESC");
              	
              	Number retailer_no=(Number) query.get("RETAILER_NO");
              	
              	Number retailer_tz=(Number) query.get("RETAILER_TZ");
              	
              	Number ret_market_type_code=(Number) query.get("RET_MARKET_TYPE_CODE");
              	
              	String ret_market_type_desc=(String) query.get("RET_MARKET_TYPE_DESC");
              	
              	String retailer_full_name=(String) query.get("RETAILER_FULL_NAME");
              	
              	Number retailer_status_code=(Number) query.get("RETAILER_STATUS_CODE");
              	
              	String retailer_status_desc=(String) query.get("RETAILER_STATUS_DESC");
              	
              	Number dwh_product_no=(Number) query.get("DWH_PRODUCT_NO");
              	
              	String dwh_product_desc=(String) query.get("DWH_PRODUCT_DESC");
              	
              	BigDecimal sales_date_amt=new BigDecimal(String.valueOf( query.get("SALES_DATE_AMT")));
            
              	Number sales_date_cnt=(Number) query.get("SALES_DATE_CNT");
              	         	
            	BigDecimal cancel_date_amt=new BigDecimal(String.valueOf( query.get("CANCEL_DATE_AMT")));
              	
              	Number cancel_date_cnt=(Number) query.get("CANCEL_DATE_CNT");
              	
              	BigDecimal valid_amt=new BigDecimal(String.valueOf( query.get("VALID_AMT")));
              	
              	Number valid_cnt=(Number) query.get("VALID_CNT");

                  RecordOut_Daily_Sales record = RecordOut_Daily_Sales.builder()
                  		.sales_dt(sales_dt)
                  		.dist_no(dist_no)
                  		.dist_name(dist_name)
                  		.pos_no(pos_no)
                  		.pos_name(pos_name)
                  		.pos_market_type_code(pos_market_type_code)
                  		.pos_market_type_desc(pos_market_type_desc)
                  		.pos_status_code(pos_status_code)
                  		.pos_status_desc(pos_status_desc)
                  		.lct_category_code(lct_category_code)
                  		.lct_category_desc(lct_category_desc)
                  		.lct_type_code(lct_type_code)
                  		.lct_type_desc(lct_type_desc)
                  		.physical_loc_code(physical_loc_code)
                  		.physical_loc_desc(physical_loc_desc)
                  		.retailer_no(retailer_no)
                  		.retailer_tz(retailer_tz)
                  		.ret_market_type_code(ret_market_type_code)
                  		.ret_market_type_desc(ret_market_type_desc)
                  		.retailer_full_name(retailer_full_name)
                  		.retailer_status_code(retailer_status_code)
                  		.retailer_status_desc(retailer_status_desc)
                  		.dwh_product_no(dwh_product_no)
                  		.dwh_product_desc(dwh_product_desc)
                  		.sales_date_amt(sales_date_amt)
                  		.sales_date_cnt(sales_date_cnt)
                  		.cancel_date_amt(cancel_date_amt)
                  		.cancel_date_cnt(cancel_date_cnt)
                  		.valid_amt(valid_amt)
                  		.valid_cnt(valid_cnt)
                          .build();
                  records.add(record);
              }

            return records;
        } catch (IndexOutOfBoundsException e) {
//            log.warn("Error Occurred: {} ", e.getMessage());
            return null;
        }


    }

}
