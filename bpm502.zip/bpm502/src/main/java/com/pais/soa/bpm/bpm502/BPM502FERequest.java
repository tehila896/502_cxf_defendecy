package com.pais.soa.bpm.bpm502;


import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pais.soa.bpm.common.SoaReqBase;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class BPM502FERequest extends SoaReqBase {

	@ToString
	@Data
	@Valid
	public static class BPM501ReqBody {

	
//		@JsonProperty("Pos_market_type_code")
//		@NotNull(message = "market id code is required")
//		@ApiModelProperty(value = "Range of days back 0-31 ",example = "1",position = 0)
//		Integer Pos_market_type_code;
//		
//		@NotNull(message = "From Date is required")
		String FromDate;

		@Min(0)
		@Max(31)
//		@ApiModelProperty(value = "Range of days back 0-31 ",example = "0",position = 2)
		Integer RangeDaysBack;

	}

	@Valid
	BPM501ReqBody SOA_Body;

}
